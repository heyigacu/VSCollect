#!/bin/bash
sbatch -a 1-6 sbatch_dock_arrayjobs.sh
