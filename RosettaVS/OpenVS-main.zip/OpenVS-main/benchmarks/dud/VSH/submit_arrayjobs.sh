#!/bin/bash
sbatch -a 1-51 sbatch_dock_arrayjobs.sh
