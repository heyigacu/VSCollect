python cluster_top.py

python save_top_hits_pdbs.py

python save_top_params.py 
# then make sure the save the params files are in the correct folder

python concat_pdb_file.py

python run_BuriedUnsatHbonds.py

python collect_unsats_info.py

./grep_lig.sh

python geometry_analysis.py
