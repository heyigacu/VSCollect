#!/bin/bash
sbatch -a 1-2 sbatch_arrayjobs.gen3d.sh
