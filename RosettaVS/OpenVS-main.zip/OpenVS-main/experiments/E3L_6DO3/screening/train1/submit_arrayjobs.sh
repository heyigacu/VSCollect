#!/bin/bash
sbatch -a 1-1%50 sbatch_dock_arrayjobs.sh
